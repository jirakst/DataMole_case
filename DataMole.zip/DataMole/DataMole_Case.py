#!/usr/bin/env python
# coding: utf-8

# # DataMole Case Study

# Experimental Scenario
# 
# Data sets consists of multiple multivariate time series. Each data set is further divided into training and test subsets. Each time series is from a different engine Ė i.e., the data can be considered to be from a fleet of engines of the same type. Each engine starts with different degrees of initial wear and manufacturing variation which is unknown to the user. This wear and variation is considered normal, i.e., it is not considered a fault condition. There are three operational settings that have a substantial effect on engine performance. These settings are also included in the data. The data is contaminated with sensor noise.
# 
# The engine is operating normally at the start of each time series, and develops a fault at some point during the series. In the training set, the fault grows in magnitude until system failure. In the test set, the time series ends some time prior to system failure. The objective of the competition is to predict the number of remaining operational cycles before failure in the test set, i.e., the number of operational cycles after the last cycle that the engine will continue to operate. Also provided a vector of true Remaining Useful Life (RUL) values for the test data.
# 
# The data are provided as a zip-compressed text file with 26 columns of numbers, separated by spaces. Each row is a snapshot of data taken during a single operational cycle, each column is a different variable.

# ## Initial thoughts

# In terms of RUL, this can be approached as time-series forecast problem (as opposed to anomaly-type problem).
# 
# Dimensional reduction (such as PCA, t-SNE, UMAP) can be considered and feature scaling might be required.
# The most intiutive way would be to use LSTM as a base model and compare those results to other ML models such as XGBoost. Another option would be to convert the time-series into images and use CNN.
# 
# Our main evaluation metrics might include Coefficient of Detrmination (Rˆ2), (R)MSE, Confusion Matrix, Precision-Recall Curve.

# # Libraries

# In[1]:


# Basic
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

# Tools
from sklearn.preprocessing import StandardScaler

# Model
from keras.preprocessing.sequence import TimeseriesGenerator
from keras.models import Sequential
from keras.layers import Dense, LSTM

# Defaults
import warnings
warnings.filterwarnings('ignore')
get_ipython().run_line_magic('matplotlib', 'inline')
pd.options.display.max_columns = None


# # Load Data

# In[2]:


colnames = ['unit', 'cycles', 'os1', 'os2', 'os3', 'sm1', 'sm2', 'sm3', 'sm4', 'sm5', 'sm6', 'sm7', 'sm8', 'sm9',
            'sm10', 'sm11', 'sm12', 'sm13', 'sm14', 'sm15', 'sm16', 'sm17', 'sm18', 'sm19', 'sm20', 'sm21']


# In[3]:


train1 = pd.read_csv('train_FD001.txt', delim_whitespace=True, names=colnames, header=None, index_col=[0])
train1.shape


# In[4]:


train2 = pd.read_csv('train_FD002.txt', delim_whitespace=True, names=colnames, header=None, index_col=[0])
train2.shape


# In[5]:


train3 = pd.read_csv('train_FD003.txt', delim_whitespace=True, names=colnames, header=None, index_col=[0])
train3.shape


# In[6]:


train4 = pd.read_csv('train_FD004.txt', delim_whitespace=True, names=colnames, header=None, index_col=[0])
train4.shape


# In[7]:


test1 = pd.read_csv('test_FD001.txt', delim_whitespace=True, names=colnames, header=None, index_col=[0])
test1.shape


# In[8]:


test2 = pd.read_csv('test_FD002.txt', delim_whitespace=True, names=colnames, header=None, index_col=[0])
test2.shape


# In[9]:


test3 = pd.read_csv('test_FD003.txt', delim_whitespace=True, names=colnames, header=None, index_col=[0])
test3.shape


# In[10]:


test4 = pd.read_csv('test_FD004.txt', delim_whitespace=True, names=colnames, header=None, index_col=[0])
test4.shape


# In[11]:


eval1 = pd.read_csv('RUL_FD001.txt', delim_whitespace=True, header=None)
eval1.shape


# In[12]:


eval2 = pd.read_csv('RUL_FD002.txt', delim_whitespace=True, header=None)
eval2.shape


# In[13]:


eval3 = pd.read_csv('RUL_FD003.txt', delim_whitespace=True, header=None)
eval3.shape


# In[14]:


eval4 = pd.read_csv('RUL_FD004.txt', delim_whitespace=True, header=None)
eval4.shape


# In[15]:


# Check
train1.head()


# In[16]:


# Check number of time series (no. of engines)
len(train1.index.unique())


# There're two ways now what to do with the datasets, assuming they're all the same type of engine under different (testing) conditions:
# 1) DFs can me merged together
# 2) Models can be blended together
# 
# However, without futher informations provided about the type of an engine, it can't be done otherwise but to choose just one train/test dataset pair to develop a model.

# # Data Exploration

# In[17]:


train1.describe()


# In[18]:


# Invidual characteristics of engine no. 1
eng = train1[train1.index==1]
ax = eng[2:].plot(x='cycles', subplots=True, figsize=(20, 30))


# In[19]:


#TODO: Calculate vectors of failure


# In[20]:


# Correlation matrix
corr = train1.corr(method='pearson')
fig, ax = plt.subplots(figsize=(15,12))
sns.heatmap(corr, linewidths=.5)


# # Data Pre-processing

# In[21]:


# Concat training and testing dataset together
split = len(train1) #split marker
data =  pd.concat(objs=[train1, test1], axis=0) #If something's goes wrong, it's here (index)
data.shape


# In[22]:


# Drop columns with no relevant informations
to_drop = ['os3', 'sm1', 'sm5', 'sm10', 'sm16', 'sm18', 'sm19']
data = data.drop(to_drop, axis=1)


# In[23]:


#TODO: exponential smoothing (sensor noise)


# Should we use RobustScaler or StandardScaler? Does an outlier forecast a possible malfunction in the future or it's just a sensor noise? I'm operating here with the first scenario, thus choosing StandardScaler.
# I'm not using Normalization because I hypothetise it's more relevant how much the readings differs TILL failure.

# In[24]:


# Scale features
sc = StandardScaler()

data.iloc[:, 1:] = sc.fit_transform(data.iloc[:, 1:])


# In[25]:


# Split data
train_df = data[:split]
test_df = data[split:]


# In[27]:


# Add target
train_df['RUL']=train_df.groupby(train_df.index)['cycles'].transform(max)-train_df['cycles'] # RUL is an inverse function of cycles


# # Model

# The most intutive way would be to use LSTM.

# In[30]:


# Get variables for a model
X_train = train_df.drop(["RUL"], axis=1)
y_train = train_df["RUL"]

print(X_train.shape)
print(y_train.shape)


# In[31]:


# Remove header for the generator
X_train.to_csv('X_train.csv', header=None)
y_train.to_csv('y_train.csv', header=None)

X = pd.read_csv('X_train.csv', header=None, index_col=[0])
y = pd.read_csv('y_train.csv', header=None, index_col=None)


# In[ ]:


# Timeseries Generator
'''
data_gen = TimeseriesGenerator(X, y,
                               length=18, sampling_rate=1,
                               batch_size=2)
'''


# We have 100 engines within our dataset, thus we need to write a generator function here to append those sequences into an array.

# In[ ]:


# Timeseries Generator
for unit in train_df.index.unique():
    train_gen.append(TimeseriesGenerator(X[X.index==unit], y[y.index==unit],
                               length=18, sampling_rate=1,
                               batch_size=2))
    
train_gen = np.asarray(train_gen)
                                                 
print("X_train shape (gen):", train_gen.shape)


# In[ ]:


#TODO: Generator function


# In[ ]:


# Model
model = Sequential()
model.add(LSTM(units=128, activation='relu', dropout=0.25, input_shape=(10,1))) # Input layer
model.add(Dense(units=1)) # Output layer
model.compile(optimizer='adam', loss='rmae')
#model.fit(X_train, y_train, epochs=30, batch_size=7)
model.fit_generator(data_gen, steps_per_epoch=len(data_gen), epochs=100)


# # Evaluation

# Here I'd compare the results from testing dataset on evaluation (ground truth) dataset provided (RUL).

# In[ ]:


# Rˆ2, RMSE


# In[ ]:


# Confusion Matrix


# In[ ]:


# Precision-Recall Curve


# # Appendix

# In[ ]:


Similar Kaggle projects:
    
https://www.kaggle.com/jirakst/credit-card-fraud-detection
https://www.kaggle.com/jirakst/ieee-fraud-detection
https://www.kaggle.com/jirakst/bitcoin-prediction-with-lstm


# GitHub: https://github.com/jirakst

# Chat-bot (Telegram): @stanbot_bot
